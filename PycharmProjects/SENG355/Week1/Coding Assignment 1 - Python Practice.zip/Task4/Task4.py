print("Welcome to my monotonous program :)")

statement = input("Enter a statement you want me to repeat! ")
timesToRepeat = input("Enter how many times you want me to print it? ")

for x in range(int(timesToRepeat)):
    print(statement)

print("Well said! Good Bye!")