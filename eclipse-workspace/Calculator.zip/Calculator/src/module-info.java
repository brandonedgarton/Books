/**
 * 
 */
/**
 * 
 */
module Str {
}