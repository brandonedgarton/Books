public class Greeting {
	
	private String message;
	
	public Greeting(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		
		return message;
	}

}
