/**
 * 
 */
/**
 * 
 */
module JunitDemo {
	requires jdk.incubator.vector;
	requires junit;
}